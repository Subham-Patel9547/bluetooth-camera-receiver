import 'package:flutter/services.dart';

class NativeBluetoothService {
  static const MethodChannel _channel =
      MethodChannel("bluetooth_camera");

  Future<void> startServer() async {
    await _channel.invokeMethod("startServer");
  }

  void setCommandListener(
      Function(String command) onCommand) {
    _channel.setMethodCallHandler((call) async {
      if (call.method == "onCommand") {
        onCommand(call.arguments as String);
      }
    });
  }
}