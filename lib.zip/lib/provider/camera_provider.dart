import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import '../core/services/camera_service.dart';
import 'package:provider/provider.dart';
import '../core/services/permission_service.dart';

import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:flutter/material.dart';

class CameraProvider extends ChangeNotifier {
  final CameraService _service = CameraService();

  CameraLensDirection _currentLens = CameraLensDirection.back;

  CameraLensDirection get currentLens => _currentLens;

  String lastVideo = "";

  final PermissionService _permissionService = PermissionService();

  String get recordingStatus => isRecording ? "Recording..." : "Ready";

  bool isInitialized = false;
  bool isRecording = false;

  Timer? _timer;

  int seconds = 0;

  String get recordingTime {
    final minute = (seconds ~/ 60).toString().padLeft(2, '0');
    final second = (seconds % 60).toString().padLeft(2, '0');

    return "$minute:$second";
  }

  CameraController? get controller => _service.controller;

  bool _isCameraBusy = false;

  Future<void> initializeCamera() async {
    if (_isCameraBusy || isInitialized) return;

    _isCameraBusy = true;

    final granted = await _permissionService.requestPermissions();

    if (!granted) {
      _isCameraBusy = false;
      return;
    }

    await _service.initializeCamera();

    isInitialized = _service.isInitialized;

    _isCameraBusy = false;

    notifyListeners();
  }

  // void handleBluetoothCommand(String cmd) {
  //   if (cmd == "START") {
  //     startRecording();
  //   }

  //   if (cmd == "STOP") {
  //     stopRecording();
  //   }
  // }

  void handleBluetoothCommand(String command) {
    switch (command.trim()) {
      case "START":
        startRecording();
        break;

      case "STOP":
        stopRecording();
        break;

      default:
        print("Unknown Command : $command");
    }
  }

  Future<void> startRecording() async {
    await _service.startRecording();

    isRecording = true;
    seconds = 0;

    _timer?.cancel();

    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      seconds++;

      notifyListeners();
    });

    notifyListeners();
  }

  Future<void> switchCamera() async {
    final cameras = await availableCameras();

    if (cameras.length < 2) return;

    _currentLens = _currentLens == CameraLensDirection.back
        ? CameraLensDirection.front
        : CameraLensDirection.back;

    await _service.switchCamera(_currentLens);

    isInitialized = _service.isInitialized;

    notifyListeners();
  }

  Future<void> stopRecording() async {
    final file = await _service.stopRecording();

    _timer?.cancel();

    if (file != null) {
      await GallerySaver.saveVideo(file.path);

      lastVideo = file.path;
    }

    isRecording = false;

    notifyListeners();
  }

  @override
  void dispose() {
    _service.disposeCamera();
    super.dispose();
  }
}
