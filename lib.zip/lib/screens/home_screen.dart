import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../provider/camera_provider.dart';
import '../widgets/status_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (!initialized) {
      initialized = true;

      Future.microtask(() {
        context.read<CameraProvider>().initializeCamera();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<CameraProvider>();

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Bluetooth Camera Receiver"),
      ),
      body: Column(
        children: [
          Expanded(
            flex: 5,
            child: provider.controller != null && provider.isInitialized
                ? AspectRatio(
                    aspectRatio: provider.controller!.value.aspectRatio,
                    child: CameraPreview(provider.controller!),
                  )
                : const Center(child: CircularProgressIndicator()),
          ),

          Expanded(
            flex: 5,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    provider.recordingTime,
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                    ),
                  ),

                  const SizedBox(height: 20),

                  StatusCard(
                    title: "Recording Status",
                    status: provider.recordingStatus,
                    color: provider.isRecording ? Colors.red : Colors.green,
                    icon: provider.isRecording
                        ? Icons.fiber_manual_record
                        : Icons.check_circle,
                  ),

                  const SizedBox(height: 20),

                  ElevatedButton.icon(
                    onPressed: () async {
                      await provider.switchCamera();
                    },
                    icon: const Icon(Icons.cameraswitch),
                    label: const Text("Switch Camera"),
                  ),

                  const SizedBox(height: 20),

                  if (provider.lastVideo.isNotEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text(
                          provider.lastVideo,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),

                  const Spacer(),

                  const Text(
                    "Waiting for Bluetooth Commands...",
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
