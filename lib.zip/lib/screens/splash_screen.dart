import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/services/native_bluetooth_service.dart';
import '../provider/camera_provider.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  final NativeBluetoothService bluetooth =
      NativeBluetoothService();

  @override
  void initState() {
    super.initState();

    initialize();
  }

  Future<void> initialize() async {

    await bluetooth.startServer();

    bluetooth.setCommandListener((command) {

      context
          .read<CameraProvider>()
          .handleBluetoothCommand(command);

    });

    await Future.delayed(
      const Duration(seconds: 2),
    );

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => const HomeScreen(),
      ),
    );

  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [

            Icon(
              Icons.bluetooth_connected,
              size: 90,
              color: Colors.blue,
            ),

            SizedBox(height: 20),

            Text(
              "Bluetooth Camera Receiver",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 20),

            CircularProgressIndicator(),

          ],
        ),
      ),
    );
  }
}